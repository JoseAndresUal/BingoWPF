﻿namespace BingoClassLibrary
{
    public interface IBola
    {
        int Numero { get; set; }
    }
}